/*
This function is to speak load message
*/
function mBotSpeak(id,state) 
{

  var mBotSpeakObj = new SpeechSynthesisUtterance();
  
  if(state == 'start') {
	  
	      
		switch(id) 
		{
			case "homePageBody" : mBotSpeakObj.text = "Welcome to Deutsche Bank's Hackathon, This it the online exam or test for people having disorder of Dementia."; 
			window.speechSynthesis.speak(mBotSpeakObj); 
			break;
		} 
	  
	  
	}
	
	  if(state == 'stop') {
	  
	      
		mBotSpeakObj.volume = 0;
	  
	  
	}

  }  


