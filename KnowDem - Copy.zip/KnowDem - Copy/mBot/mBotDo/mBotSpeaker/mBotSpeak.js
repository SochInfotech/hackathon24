/*
This function is to speak load message
*/

function mBotSpeak(id) 
{
  alert(id);
  var mBotSpeakObj = new SpeechSynthesisUtterance();
    switch(id) 
    {
        case "homePageBody" : mBotSpeakObj.text = "Welcome to Policy Portal"; window.speechSynthesis.speak(mBotSpeakObj); break;
    }
  }  

  export { mBotSpeak};
