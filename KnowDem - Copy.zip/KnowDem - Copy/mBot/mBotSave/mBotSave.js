/*
The code below will save
the actions.
*/
function mBotSaveLoads() {

localStorage.setItem("firstLoad", 1);

}

function mBotSaveRefresh() {
localStorage.setItem()
}
