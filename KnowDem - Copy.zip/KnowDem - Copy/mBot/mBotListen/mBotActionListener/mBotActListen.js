document.getElementById("myBtn").addEventListener("click", function() {
  myFunction(p1, p2);
});