var speechRecognition = window.webkitSpeechRecognition

var recognition = new speechRecognition()

var textbox = $("#textbox")

var instructions = $("#instructions")

var content = ''

recognition.continuous = true

// recognition is started

recognition.onstart = function() {

 instructions.text("Voice Recognition is On")

}

recognition.onspeechend = function() {

 instructions.text("No Activity")

}

recognition.onerror = function() {

 instructions.text("Try Again")

}

recognition.onresult = function(event) {

 var current = event.resultIndex;

 var transcript = event.results[current][0].transcript



 content += transcript

 textbox.val(content)

}

$("#start-btn").click(function(event) {

 recognition.start()

})

textbox.on('input', function() {

 content = $(this).val()

})

// $(function () {
//     try {
//       var recognition = new webkitSpeechRecognition();
//     } catch (e) {
//       var recognition = Object;
//       alert('test');
//     }
//     alert("1");
//     recognition.continuous = true;
//     alert("2");
//     recognition.interimResults = true;
//     alert("3");
//     recognition.onresult = function (event) {
//       var txtRec = '';
//       alert("4");
//       for (var i = event.resultIndex; i < event.results.length; ++i) {
          
//         txtRec += event.results[i][0].transcript;
//       }
//       alert(txtRec);
//       $('#txtArea').val(txtRec);
//     };
//     $('#startRecognition').click(function () {
//       $('#txtArea').focus();
//       recognition.start();
//     });
//     $('#stopRecognition').click(function () {
//       recognition.stop();
//     });
//   });